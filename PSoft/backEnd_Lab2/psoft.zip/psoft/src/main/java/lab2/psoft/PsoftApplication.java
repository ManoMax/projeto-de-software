package lab2.psoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PsoftApplication {

	public static void main(String[] args) {
		SpringApplication.run(PsoftApplication.class, args);
	}

}
